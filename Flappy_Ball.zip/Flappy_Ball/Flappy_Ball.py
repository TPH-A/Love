# -*- coding:utf-8 -*-
import pygame, sys, time, random
from pygame.locals import *
# init
pygame.init()
pygame.mixer.init()
# create windows
screen = pygame.display.set_mode((700, 600))
pygame.display.set_caption("Flappy_Ball")
pygame.display.set_icon(pygame.image.load("images/icon.ico"))
# load image
ball = pygame.image.load("images/ball.png")
ball = pygame.transform.smoothscale(ball, (100, 100))
sky = pygame.image.load("images/sky.jpg")
sky = pygame.transform.smoothscale(sky, (700, 600))
play = pygame.image.load("images/play.png")
play = pygame.transform.smoothscale(play, (50, 50))
back = pygame.image.load("images/back.png")
back = pygame.transform.smoothscale(back, (50, 50))
tph = pygame.image.load("images/LOGO.png")
tph = pygame.transform.smoothscale(tph, (300, 275))
tphrect = tph.get_rect()
tphrect.centerx = 350
tphrect.centery = 300
# game run starts
starts = False
# range
rect_ord = -2
rect_ord1 = -1
# save
rects = []
# get time
point = time.time()
move_pint = time.time()
# ball
bx = 50
by = 275
# rect
rx = 700
ry = 0
# show logo
screen.fill((254, 254, 254))
screen.blit(tph, tphrect)
pygame.display.flip()
time.sleep(3)
# start
while True:
    '''get mouse and event'''
    x, y = pygame.mouse.get_pos()
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == QUIT:
            sys.exit()
        if event.type == MOUSEBUTTONDOWN:
            if event.button == 1:
                if 325 <= x <= 375 and 275 <= y <= 325:
                    starts = True
                if starts:
                    if 0 <= x <= 50 and 0 <= y <= 50:
                        starts = False
    # game not start
    if not starts:
        screen.blit(sky, (0, 0))
        screen.blit(play, (325, 275))
    # game start
    elif starts:
        if keys[K_UP]:
            by -= 2
        if keys[K_DOWN]:
            by += 2
        if by <= -17:
            by += 2
        if by >= 530:
            by -= 2
        if time.time() - point >= 2:
            rx = 700
            rect_ord += 1
            rect_ord1 += 2
            rh = random.randint(150, 250)
            ry2 = random.randint(500, 600)
            rects.append(rh)
            rects.append(ry2)
            point = time.time()
        if time.time() - move_pint >= 0.5:
            rx -= 1
        screen.blit(sky, (0, 0))
        pygame.draw.rect(screen, (230, 0, 20), (rx, ry, 50, rects[rect_ord]), 0)
        pygame.draw.rect(screen, (230, 0, 20), (rx, rects[rect_ord1], 50, 300), 0)
        screen.blit(ball, (bx, by))
        screen.blit(back, (0, 0))
    # update the game
    pygame.display.update()
